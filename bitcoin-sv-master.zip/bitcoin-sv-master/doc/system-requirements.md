#Bitcoin SV System Requirements

The minimum suggested system requirements for the current release of Bitcoin SV can be found on the
website [here](https://bitcoinsv.io/2019/08/02/bitcoin-sv-node-system-requirements/).
