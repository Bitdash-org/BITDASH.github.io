Bitcoin SV
=====================

Intro
-----
Bitcoin SV is an implementation of a node for the Bitcoin SV network and is one of the pieces of software that provide
the backbone of the network. It downloads and stores the entire history of Bitcoin SV transactions (which is currently
several GBs); depending on the speed of your computer and network connection, the synchronization process can take
anywhere from a few hours to a day or more.

Setup
-----
Unpack the files into a directory and run bitcoind.exe.

### Need Help?

* Log an issue on [GitHub] (https://github.com/bitcoin-sv/bitcoin-sv/issues)
* Ask for help on the [Bitcoin SV Subreddit](https://www.reddit.com/r/bitcoinSV/) or
[Bictoin SV Subreddit](https://www.reddit.com/r/bitcoincashSV/).
